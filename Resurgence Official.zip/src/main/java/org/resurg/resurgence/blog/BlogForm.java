package org.resurg.resurgence.blog;

public class BlogForm {
}
