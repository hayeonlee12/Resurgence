package org.resurg.resurgence.blog;

public interface BlogRepository {
}
